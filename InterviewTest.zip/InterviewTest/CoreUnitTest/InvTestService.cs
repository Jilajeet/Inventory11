﻿using Inventory.IServices;
using Inventory.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CoreUnitTest
{
    class InvTestService : IInventoryService
    {
        private readonly List<InvetoryDetail> _inventoryDetail;
        public InvTestService()
        {
            _inventoryDetail = new List<InvetoryDetail>()
            {
                new InvetoryDetail() { InvId = 1,
                    Name = "Orange Juice", Description="Orange Tree", Price = 5.00M },
                new InvetoryDetail() { InvId = 2,
                    Name = "Diary Milk", Description="Cow", Price = 4.00M },
                new InvetoryDetail() { InvId = 3,
                    Name = "Frozen Pizza", Description="Uncle Mickey", Price = 12.00M }
            };
        }
        public IEnumerable<InvetoryDetail> GetInventory()
        {
            return _inventoryDetail;
        }
        
        public InvetoryDetail AddInventory(InvetoryDetail inventory)
        {
            inventory.Name = "table";
            inventory.Description = "table description";
            inventory.Price = 100;
            _inventoryDetail.Add(inventory);
            return inventory;
        }

        public InvetoryDetail UpdateInventory(InvetoryDetail inventory)
        {
            _ = _inventoryDetail.Where(inv=>inv.InvId==inventory.InvId).
                    Select(upd =>
                    {
                        upd.Name = inventory.Name;
                        upd.Description = inventory.Description;
                        upd.Price = inventory.Price;
                        return upd;
                    }).ToList();
            return inventory;
        }

        public InvetoryDetail DeleteInventory(int id)
        {
            InvetoryDetail obj = _inventoryDetail.FirstOrDefault(x => x.InvId == id);
            _inventoryDetail.Remove(_inventoryDetail.FirstOrDefault(x=>x.InvId==id));
            return obj;
        }

        public InvetoryDetail GetInventoryById(int id)
        {
            return _inventoryDetail.FirstOrDefault(a => a.InvId == id);
        }
    }
}
