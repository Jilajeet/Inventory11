using Inventory.Controllers;
using Inventory.IServices;
using Inventory.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using Xunit;

namespace CoreUnitTest
{
    public class UnitTest1
    {

        private readonly InventoryController _controller;
        private readonly IInventoryService _service;
        public UnitTest1()
        {
            _service = new InvTestService();
            _controller = new InventoryController(_service);
        }

        [Fact]
        public void Get_WhenCalled_ReturnsOkResult()
        {
            // Act
            var okResult = _controller.GetInventory();
            
            // Assert
            Assert.IsType<OkObjectResult>(okResult.Result);
        }

        [Fact]
        public void GetById_WhenCalled_ReturnsOkResult()
        {
            // Act
            var okResult = _controller.GetInventoryId(1);

            // Assert
            Assert.IsType<OkObjectResult>(okResult.Result);
        }

        [Fact]
        public void GetById_WhenCalled_ReturnsNotFoundResult()
        {
            // Act
            var okResult = _controller.GetInventoryId(0);

            // Assert
            Assert.IsType<OkObjectResult>(okResult.Result);
        }

        [Fact]
        public void Add_WhenCalled_ReturnsOKResult()
        {
            // Act
            InvetoryDetail testItem = new InvetoryDetail()
            {
                InvId = 4,
                Name = "Guinness Original 6 Pack",
                Description = "Guinness",
                Price = 12
            };
            var okResult = _controller.AddInventory(testItem);

            // Assert
            Assert.IsType<OkObjectResult>(okResult.Result);
        }

        [Fact]
        public void Delete_WhenCalled_ReturnsOkResult()
        {
            // Act
            var okResult = _controller.DeleteInventory(4);

            // Assert
            Assert.IsType<OkObjectResult>(okResult.Result);
        }

        
    }
}
