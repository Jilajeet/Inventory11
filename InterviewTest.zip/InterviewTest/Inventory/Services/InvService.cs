﻿using Inventory.IServices;
using Inventory.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Inventory.Services
{
    public class InvService : IInventoryService
    {
         readonly InventoryContext  _invDbContext;
        public InvService(InventoryContext _invDb)
        {
            _invDbContext = _invDb;
        }
        public IEnumerable<InvetoryDetail> GetInventory()
        {
            var _invDetail = _invDbContext.InvetoryDetails.ToList();
            return _invDetail;
        }
        public InvetoryDetail AddInventory(InvetoryDetail inventory)
        {
            if (inventory != null)
            {
                _invDbContext.InvetoryDetails.Add(inventory);
                _invDbContext.SaveChanges();
                return inventory;
            }
            return null;
        }
        public InvetoryDetail UpdateInventory(InvetoryDetail inventory)
        {
            _invDbContext.Entry(inventory).State = EntityState.Modified;
            _invDbContext.SaveChanges();
            return inventory;
        }
        public InvetoryDetail DeleteInventory(int id)
        {
            var employee = _invDbContext.InvetoryDetails.FirstOrDefault(x => x.InvId == id);
            _invDbContext.Entry(employee).State = EntityState.Deleted;
            _invDbContext.SaveChanges();
            return employee;
        }
        public InvetoryDetail GetInventoryById(int id)
        {
            var employee = _invDbContext.InvetoryDetails.FirstOrDefault(x => x.InvId == id);
            return employee;
        }
    }
}
