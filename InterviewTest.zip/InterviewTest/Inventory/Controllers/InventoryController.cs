﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Inventory.IServices;
using Inventory.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Inventory.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InventoryController : ControllerBase
    {
        private readonly IInventoryService _inventorySerivice;

        //injection the interface service to the constructor
        public InventoryController(IInventoryService invSerive)
        {
            _inventorySerivice = invSerive;
        }

        /// <summary>
        /// Get the inventory details
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("[action]")]
        [Route("api/Inventory/GetInventory")]
        public ActionResult<IEnumerable<InvetoryDetail>> GetInventory()
        {
            IEnumerable<InvetoryDetail> _invDetails;
            try
            {
                _invDetails =  _inventorySerivice.GetInventory();
                if (_invDetails == null)
                {
                    throw new ArgumentException($"No Inventory Details found");
                }
            }
            catch (Exception ex)
            {
                throw new ArgumentException($"No Inventory Details found. "+"Error:"+ex.Message);
            }

           
            return Ok(_invDetails);

        }

        /// <summary>
        /// Add inventory details
        /// </summary>
        /// <param name="ObjInve"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("[action]")]
        [Route("api/Inventory/AddInventory")]
        public ActionResult<InvetoryDetail> AddInventory(InvetoryDetail ObjInve)
        {
            InvetoryDetail _invDetails;
            try
            {
                if(ObjInve!=null)
                {
                    if(string.IsNullOrEmpty(ObjInve.Name) || string.IsNullOrEmpty(ObjInve.Description)|| string.IsNullOrEmpty(Convert.ToString(ObjInve.Price)))
                    {
                        throw new ArgumentException($"All field are mendotory.");
                    }
                    _invDetails = _inventorySerivice.AddInventory(ObjInve);

                    if (_invDetails == null)
                    {
                        throw new ArgumentException($"Fail to add Inventory.");
                    }
                }
                else
                {
                    throw new ArgumentException($"All field are mendotory.");
                }
                
            }
            catch (Exception ex)
            {
                throw new ArgumentException($"Fail to add Inventory. " + "Error:" + ex.Message);
            }
            return Ok( _invDetails);
        }

        /// <summary>
        /// Edit the inventory details
        /// </summary>
        /// <param name="ObjInve"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("[action]")]
        [Route("api/Inventory/EditInventory")]
        public ActionResult<InvetoryDetail> EditInventory(InvetoryDetail ObjInve)
        {
            InvetoryDetail _invDetails;
            try
            {
                _invDetails = _inventorySerivice.UpdateInventory(ObjInve);

                if (_invDetails == null)
                {
                    throw new ArgumentException($"Fail to update Inventory.");
                }
            }
            catch (Exception ex)
            {
                throw new ArgumentException($"Fail to add update. " + "Error:" + ex.Message);
            }
            return Ok(_invDetails);
        }

        /// <summary>
        /// Delete the inventory details
        /// </summary>
        /// <param name="invId"></param>
        /// <returns></returns>
        [HttpDelete]
        [Route("[action]")]
        [Route("api/Inventory/DeleteInventory")]
        public ActionResult<InvetoryDetail> DeleteInventory(int invId)
        {
            InvetoryDetail _invDetails;
            try
            {
                _invDetails = _inventorySerivice.DeleteInventory(invId);

                if (_invDetails == null)
                {
                    throw new ArgumentException($"Fail to delete Inventory for inv id."+invId);
                }
            }
            catch (Exception ex)
            {
                throw new ArgumentException($"Fail to  delete for inv id " + invId +" Error:" + ex.Message);
            }
            return Ok( _invDetails);
        }

        /// <summary>
        /// Get the inventory details by inv id
        /// </summary>
        /// <param name="invId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("[action]")]
        [Route("api/Inventory/GetInventoryId")]
        public ActionResult<InvetoryDetail> GetInventoryId(int invId)
        {
            InvetoryDetail _invDetails;
            try
            {
                _invDetails = _inventorySerivice.GetInventoryById(invId);

                if (_invDetails == null)
                {
                    throw new ArgumentException($"Fail to Get Inventory for inv id." + invId);
                }
            }
            catch (Exception ex)
            {
                throw new ArgumentException($"Fail to Get Inventory for inv id." + invId + " Error:" + ex.Message);
            }
            return Ok(_invDetails);
            
        }
    }
}
