﻿using Inventory.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Inventory.IServices
{
   public interface IInventoryService
    {
        IEnumerable<InvetoryDetail> GetInventory();
        InvetoryDetail GetInventoryById(int id);
        InvetoryDetail AddInventory(InvetoryDetail inventory);
        InvetoryDetail UpdateInventory(InvetoryDetail inventory);
        InvetoryDetail DeleteInventory(int id);
    }
}
